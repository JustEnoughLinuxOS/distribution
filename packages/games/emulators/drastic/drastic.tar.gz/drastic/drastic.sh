#!/bin/bash

source /etc/profile

BINPATH="/usr/bin"
EXECLOG="/var/log/exec.log"

cd /storage/.config/drastic/aarch64/drastic/
maxperf
./drastic "$1" >> $EXECLOG 2>&1
normperf
